#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS // Network Security Scanner
Eina educativa d'anàlisi de xarxes. Utilitzeu-la NOMÉS sobre equips
i xarxes on tingueu autorització.
"""

import ipaddress
import platform
import queue
import re
import socket
import subprocess
import threading
import time
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

# ----------------------------------------------------------------------
# Dades: serveis coneguts i indicadors de risc
# ----------------------------------------------------------------------
SERVICES = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 111: "RPCbind", 135: "MSRPC", 139: "NetBIOS",
    143: "IMAP", 443: "HTTPS", 445: "SMB", 465: "SMTPS", 587: "SMTP-Sub",
    993: "IMAPS", 995: "POP3S", 1433: "MSSQL", 1521: "Oracle",
    3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 5900: "VNC",
    6379: "Redis", 8080: "HTTP-Alt", 8443: "HTTPS-Alt", 9200: "Elasticsearch",
    27017: "MongoDB",
}

# port -> (nivell, missatge)
RISKS = {
    21: ("MITJÀ", "FTP obert - transmet credencials i dades sense xifrat."),
    23: ("ALT", "TELNET obert - transmet informació sense xifrat."),
    80: ("BAIX", "HTTP sense xifrat - considereu redirigir a HTTPS."),
    8080: ("BAIX", "HTTP alternatiu sense xifrat."),
    139: ("MITJÀ", "NetBIOS exposat - possible fuga d'informació."),
    445: ("ALT", "SMB exposat - servei sovint objectiu d'atacs."),
    3389: ("ALT", "RDP exposat - escriptori remot accessible a la xarxa."),
    5900: ("ALT", "VNC exposat - accés remot sovint amb autenticació feble."),
    6379: ("ALT", "Redis exposat - sovint sense autenticació per defecte."),
    9200: ("ALT", "Elasticsearch exposat - possible accés obert a dades."),
    27017: ("ALT", "MongoDB exposat - revisar autenticació i accés extern."),
    3306: ("MITJÀ", "MySQL exposat - no hauria de ser accessible externament."),
    5432: ("MITJÀ", "PostgreSQL exposat - no hauria de ser accessible externament."),
    1433: ("MITJÀ", "MSSQL exposat - no hauria de ser accessible externament."),
}

# Paleta (estil SOC)
BG = "#0b1220"
PANEL = "#111a2e"
PANEL2 = "#16223b"
FG = "#d6e2f5"
MUTED = "#7b8ba8"
ACCENT = "#00e5ff"
GREEN = "#2ee6a6"
YELLOW = "#ffc857"
RED = "#ff5c7a"

IS_WINDOWS = platform.system().lower() == "windows"


def now():
    return time.strftime("%H:%M:%S")


def parse_ports(text):
    """Accepta '1-1024', '80', '22,80,443' o combinacions."""
    ports = set()
    for part in text.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            a, b = int(a), int(b)
            if a > b:
                a, b = b, a
            ports.update(range(a, b + 1))
        else:
            ports.add(int(part))
    if not ports or min(ports) < 1 or max(ports) > 65535:
        raise ValueError("Els ports han d'estar entre 1 i 65535")
    return sorted(ports)


def clean_target(t):
    t = t.strip()
    t = re.sub(r"^[a-zA-Z]+://", "", t)
    return t.split("/")[0]


# ----------------------------------------------------------------------
# Aplicació
# ----------------------------------------------------------------------
class NexusApp:
    def __init__(self, root):
        self.root = root
        root.title("NEXUS // Network Security Scanner")
        root.geometry("1000x680")
        root.minsize(900, 600)
        root.configure(bg=BG)

        self.q = queue.Queue()          # cua thread-safe cap a la GUI
        self.stop_event = threading.Event()
        self.proc = None                # subprocés actiu (ping/traceroute)
        self.busy = False
        self.open_ports = []            # [(port, servei, banner)]
        self.total_ports = 0
        self.done_ports = 0
        self.lock = threading.Lock()

        self._style()
        self._build_header()
        self._build_notebook()
        self._build_statusbar()

        self.log("NEXUS iniciat. Utilitzeu-lo només amb autorització.")
        self.root.after(100, self._poll_queue)

    # ------------------------- estil -------------------------
    def _style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure("TFrame", background=BG)
        s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", background=PANEL, foreground=MUTED,
                    padding=(16, 8), font=("Segoe UI", 10, "bold"))
        s.map("TNotebook.Tab",
              background=[("selected", PANEL2)],
              foreground=[("selected", ACCENT)])
        s.configure("Treeview", background=PANEL, fieldbackground=PANEL,
                    foreground=FG, rowheight=26, borderwidth=0,
                    font=("Consolas", 10))
        s.configure("Treeview.Heading", background=PANEL2, foreground=ACCENT,
                    font=("Segoe UI", 10, "bold"), borderwidth=0)
        s.map("Treeview", background=[("selected", "#1f3a5f")])
        s.configure("Horizontal.TProgressbar", troughcolor=PANEL,
                    background=ACCENT, borderwidth=0)

    def _button(self, parent, text, cmd, color=ACCENT):
        return tk.Button(parent, text=text, command=cmd, bg=color, fg="#001018",
                         activebackground=FG, relief="flat", bd=0,
                         font=("Segoe UI", 10, "bold"), padx=14, pady=6,
                         cursor="hand2")

    # ------------------------- capçalera -------------------------
    def _build_header(self):
        top = tk.Frame(self.root, bg=PANEL)
        top.pack(fill="x")

        tk.Label(top, text="NEXUS", bg=PANEL, fg=ACCENT,
                 font=("Consolas", 22, "bold")).pack(side="left", padx=(16, 4), pady=10)
        tk.Label(top, text="// Network Security Scanner", bg=PANEL, fg=MUTED,
                 font=("Consolas", 11)).pack(side="left", pady=10)

        ctl = tk.Frame(self.root, bg=BG)
        ctl.pack(fill="x", padx=16, pady=10)

        tk.Label(ctl, text="OBJECTIU", bg=BG, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).grid(row=0, column=0, sticky="w")
        tk.Label(ctl, text="PORTS", bg=BG, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).grid(row=0, column=1, sticky="w", padx=(10, 0))

        self.target_var = tk.StringVar(value="127.0.0.1")
        self.ports_var = tk.StringVar(value="1-1024")
        ekw = dict(bg=PANEL2, fg=FG, insertbackground=ACCENT, relief="flat",
                   font=("Consolas", 11))
        tk.Entry(ctl, textvariable=self.target_var, width=32, **ekw).grid(
            row=1, column=0, ipady=6, sticky="w")
        tk.Entry(ctl, textvariable=self.ports_var, width=18, **ekw).grid(
            row=1, column=1, ipady=6, padx=(10, 0), sticky="w")

        self.btn_scan = self._button(ctl, "▶ ESCANEJAR", self.start_scan)
        self.btn_scan.grid(row=1, column=2, padx=(14, 0))
        self.btn_stop = self._button(ctl, "■ STOP", self.stop_all, RED)
        self.btn_stop.grid(row=1, column=3, padx=(8, 0))

    # ------------------------- pestanyes -------------------------
    def _build_notebook(self):
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=16, pady=(0, 6))

        self._tab_dashboard()
        self._tab_ports()
        self._tab_services()
        self._tab_text("Ping", "ping")
        self._tab_text("Traceroute", "trace")
        self._tab_text("WHOIS", "whois")
        self._tab_vulns()

    def _new_tab(self, title):
        f = tk.Frame(self.nb, bg=BG)
        self.nb.add(f, text=title)
        return f

    def _textbox(self, parent):
        t = scrolledtext.ScrolledText(parent, bg=PANEL, fg=FG, relief="flat",
                                      insertbackground=ACCENT,
                                      font=("Consolas", 10), wrap="word",
                                      state="disabled", borderwidth=0)
        t.tag_config("ok", foreground=GREEN)
        t.tag_config("warn", foreground=YELLOW)
        t.tag_config("bad", foreground=RED)
        t.tag_config("info", foreground=ACCENT)
        t.tag_config("muted", foreground=MUTED)
        return t

    def _append(self, widget, text, tag=None):
        widget.configure(state="normal")
        widget.insert("end", text, tag)
        widget.see("end")
        widget.configure(state="disabled")

    def _clear(self, widget):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.configure(state="disabled")

    # ----- Dashboard -----
    def _tab_dashboard(self):
        f = self._new_tab("Dashboard")
        cards = tk.Frame(f, bg=BG)
        cards.pack(fill="x", pady=12)

        self.card_vars = {}
        for i, (key, label, color) in enumerate([
            ("ports", "PORTS OBERTS", GREEN),
            ("services", "SERVEIS DETECTATS", ACCENT),
            ("risks", "INDICADORS DE RISC", YELLOW),
            ("state", "ESTAT", FG),
        ]):
            c = tk.Frame(cards, bg=PANEL, padx=18, pady=14)
            c.grid(row=0, column=i, padx=6, sticky="nsew")
            cards.columnconfigure(i, weight=1)
            var = tk.StringVar(value="0" if key != "state" else "Inactiu")
            self.card_vars[key] = var
            tk.Label(c, textvariable=var, bg=PANEL, fg=color,
                     font=("Consolas", 24, "bold")).pack(anchor="w")
            tk.Label(c, text=label, bg=PANEL, fg=MUTED,
                     font=("Segoe UI", 8, "bold")).pack(anchor="w")

        self.progress = ttk.Progressbar(f, mode="determinate",
                                        style="Horizontal.TProgressbar")
        self.progress.pack(fill="x", padx=6, pady=(4, 10))

        tk.Label(f, text="ACTIVITY LOG", bg=BG, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=6)
        self.log_box = self._textbox(f)
        self.log_box.pack(fill="both", expand=True, padx=6, pady=(2, 6))

    # ----- Ports -----
    def _tab_ports(self):
        f = self._new_tab("Ports")
        cols = ("port", "proto", "state", "service")
        self.tree_ports = ttk.Treeview(f, columns=cols, show="headings")
        for c, t, w in zip(cols, ("PORT", "PROTOCOL", "ESTAT", "SERVEI"),
                           (100, 120, 120, 220)):
            self.tree_ports.heading(c, text=t)
            self.tree_ports.column(c, width=w, anchor="w")
        self.tree_ports.pack(fill="both", expand=True, pady=8)

    # ----- Services -----
    def _tab_services(self):
        f = self._new_tab("Services")
        cols = ("port", "service", "banner")
        self.tree_serv = ttk.Treeview(f, columns=cols, show="headings")
        for c, t, w in zip(cols, ("PORT", "SERVEI", "BANNER"), (90, 160, 600)):
            self.tree_serv.heading(c, text=t)
            self.tree_serv.column(c, width=w, anchor="w")
        self.tree_serv.pack(fill="both", expand=True, pady=8)

    # ----- Ping / Traceroute / WHOIS -----
    def _tab_text(self, title, kind):
        f = self._new_tab(title)
        bar = tk.Frame(f, bg=BG)
        bar.pack(fill="x", pady=8)
        cmd = {"ping": self.run_ping, "trace": self.run_trace,
               "whois": self.run_whois}[kind]
        label = {"ping": "▶ Executar Ping", "trace": "▶ Executar Traceroute",
                 "whois": "▶ Consultar WHOIS"}[kind]
        self._button(bar, label, cmd).pack(side="left")
        box = self._textbox(f)
        box.pack(fill="both", expand=True)
        setattr(self, f"box_{kind}", box)

    # ----- Vulnerabilities -----
    def _tab_vulns(self):
        f = self._new_tab("Vulnerabilities")
        tk.Label(f, text="Primera anàlisi basada en ports i serveis exposats. "
                         "No s'executa cap exploit.",
                 bg=BG, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(8, 4))
        self.box_vuln = self._textbox(f)
        self.box_vuln.pack(fill="both", expand=True)

    # ----- Barra d'estat -----
    def _build_statusbar(self):
        self.status = tk.StringVar(value="Llest")
        tk.Label(self.root, textvariable=self.status, bg=PANEL, fg=MUTED,
                 anchor="w", padx=12, font=("Consolas", 9)).pack(fill="x", side="bottom")

    # ------------------------- utilitats GUI -------------------------
    def log(self, msg, tag="muted"):
        self._append(self.log_box, f"[{now()}] {msg}\n", tag)

    def post(self, kind, *payload):
        """Els threads NO toquen Tkinter: envien missatges a la cua."""
        self.q.put((kind, payload))

    def set_busy(self, busy, state_text=None):
        self.busy = busy
        self.card_vars["state"].set(state_text or ("Analitzant..." if busy else "Inactiu"))
        self.status.set("Treballant..." if busy else "Llest")

    def _poll_queue(self):
        try:
            while True:
                kind, p = self.q.get_nowait()
                self._handle(kind, p)
        except queue.Empty:
            pass
        self.root.after(80, self._poll_queue)

    def _handle(self, kind, p):
        if kind == "log":
            self.log(p[0], p[1] if len(p) > 1 else "muted")
        elif kind == "open":
            port, service, banner = p
            self.open_ports.append((port, service, banner))
            self.tree_ports.insert("", "end", values=(port, "TCP", "OPEN", service))
            self.tree_serv.insert("", "end", values=(port, service, banner or "-"))
            self.card_vars["ports"].set(str(len(self.open_ports)))
            self.card_vars["services"].set(str(len({s for _, s, _ in self.open_ports})))
            self.log(f"Port {port}/TCP obert ({service})", "ok")
        elif kind == "progress":
            self.progress["value"] = p[0]
        elif kind == "scan_done":
            self._finish_scan(p[0])
        elif kind == "text":
            box, text, tag = p
            self._append(getattr(self, box), text, tag)
        elif kind == "cmd_done":
            self.set_busy(False)
            self.log(p[0], "info")

    # ------------------------- ESCANEIG -------------------------
    def start_scan(self):
        if self.busy:
            messagebox.showinfo("NEXUS", "Ja hi ha una tasca en execució.")
            return
        target = clean_target(self.target_var.get())
        if not target:
            messagebox.showwarning("NEXUS", "Introduïu una IP o domini.")
            return
        try:
            ports = parse_ports(self.ports_var.get())
        except ValueError as e:
            messagebox.showerror("NEXUS", f"Rang de ports no vàlid:\n{e}")
            return

        # Reinici de resultats
        for t in (self.tree_ports, self.tree_serv):
            t.delete(*t.get_children())
        self.open_ports.clear()
        self._clear(self.box_vuln)
        for k in ("ports", "services", "risks"):
            self.card_vars[k].set("0")
        self.progress["value"] = 0
        self.total_ports = len(ports)
        self.done_ports = 0
        self.stop_event.clear()

        self.set_busy(True, "Escanejant...")
        self.log(f"Escaneig de {target} ({len(ports)} ports)", "info")
        threading.Thread(target=self._scan_manager, args=(target, ports),
                         daemon=True).start()

    def _scan_manager(self, target, ports):
        try:
            ip = socket.gethostbyname(target)
        except socket.gaierror:
            self.post("log", f"No es pot resoldre '{target}'", "bad")
            self.post("scan_done", False)
            return
        self.post("log", f"Objectiu resolt: {ip}", "info")

        pending = queue.Queue()
        for p in ports:
            pending.put(p)

        workers = []
        for _ in range(min(150, len(ports))):
            t = threading.Thread(target=self._scan_worker, args=(ip, pending), daemon=True)
            t.start()
            workers.append(t)
        for t in workers:
            t.join()
        self.post("scan_done", not self.stop_event.is_set())

    def _scan_worker(self, ip, pending):
        while not self.stop_event.is_set():
            try:
                port = pending.get_nowait()
            except queue.Empty:
                return
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.8)
            try:
                if s.connect_ex((ip, port)) == 0:
                    banner = self._grab_banner(s, ip, port)
                    self.post("open", port, SERVICES.get(port, "Desconegut"), banner)
            except OSError:
                pass
            finally:
                s.close()
            with self.lock:
                self.done_ports += 1
                if self.done_ports % 10 == 0 or self.done_ports == self.total_ports:
                    self.post("progress", self.done_ports * 100 / self.total_ports)

    @staticmethod
    def _grab_banner(s, ip, port):
        """Banner grabbing bàsic."""
        try:
            s.settimeout(1.2)
            if port in (80, 8080, 8000, 8888):
                s.sendall(f"HEAD / HTTP/1.0\r\nHost: {ip}\r\n\r\n".encode())
            data = s.recv(256).decode("utf-8", errors="ignore").strip()
            return " ".join(data.split())[:120]
        except (OSError, UnicodeError):
            return ""

    def _finish_scan(self, completed):
        self.progress["value"] = 100 if completed else self.progress["value"]
        self.set_busy(False, "Completat" if completed else "Aturat")
        self.log("Escaneig completat." if completed else "Escaneig aturat per l'usuari.",
                 "ok" if completed else "warn")
        self._analyze_risks()

    # ------------------------- VULNERABILITATS -------------------------
    def _analyze_risks(self):
        self._clear(self.box_vuln)
        found = 0
        colors = {"ALT": "bad", "MITJÀ": "warn", "BAIX": "info"}
        for port, service, _ in sorted(self.open_ports):
            if port in RISKS:
                level, msg = RISKS[port]
                self._append(self.box_vuln, f"[!] [{level}] Port {port} ({service}): {msg}\n",
                             colors[level])
                found += 1
        if found == 0:
            self._append(self.box_vuln,
                         "No s'han detectat indicadors de risc coneguts.\n", "ok")
        self.card_vars["risks"].set(str(found))
        self.log(f"Anàlisi de riscos: {found} indicador(s).", "warn" if found else "ok")

    # ------------------------- PING / TRACEROUTE -------------------------
    def _run_command(self, cmd, box, title):
        if self.busy:
            messagebox.showinfo("NEXUS", "Ja hi ha una tasca en execució.")
            return
        self._clear(getattr(self, box))
        self.stop_event.clear()
        self.set_busy(True, title)
        self.log(f"{title}: {' '.join(cmd)}", "info")
        threading.Thread(target=self._command_worker, args=(cmd, box, title),
                         daemon=True).start()

    def _command_worker(self, cmd, box, title):
        try:
            kwargs = {}
            if IS_WINDOWS:
                kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
            self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, text=True,
                                         errors="ignore", **kwargs)
            for line in self.proc.stdout:
                if self.stop_event.is_set():
                    break
                self.post("text", box, line, None)
            self.proc.wait()
        except FileNotFoundError:
            self.post("text", box, f"Comanda '{cmd[0]}' no trobada al sistema.\n", "bad")
        except Exception as e:
            self.post("text", box, f"Error: {e}\n", "bad")
        finally:
            self.proc = None
            self.post("cmd_done", f"{title} finalitzat.")

    def run_ping(self):
        target = clean_target(self.target_var.get())
        if not target:
            return messagebox.showwarning("NEXUS", "Introduïu un objectiu.")
        cmd = ["ping", "-n" if IS_WINDOWS else "-c", "4", target]
        self._run_command(cmd, "box_ping", "Ping")

    def run_trace(self):
        target = clean_target(self.target_var.get())
        if not target:
            return messagebox.showwarning("NEXUS", "Introduïu un objectiu.")
        cmd = ["tracert", "-d", target] if IS_WINDOWS else ["traceroute", "-n", target]
        self._run_command(cmd, "box_trace", "Traceroute")

    # ------------------------- WHOIS -------------------------
    def run_whois(self):
        if self.busy:
            messagebox.showinfo("NEXUS", "Ja hi ha una tasca en execució.")
            return
        target = clean_target(self.target_var.get())
        if not target:
            return messagebox.showwarning("NEXUS", "Introduïu un objectiu.")
        self._clear(self.box_whois)
        self.stop_event.clear()
        self.set_busy(True, "WHOIS")
        self.log(f"WHOIS de {target}", "info")
        threading.Thread(target=self._whois_worker, args=(target,), daemon=True).start()

    def _whois_worker(self, target):
        try:
            # Detecció d'IP privada
            try:
                ip = ipaddress.ip_address(target)
            except ValueError:
                ip = None
            if ip is None:
                try:
                    ip = ipaddress.ip_address(socket.gethostbyname(target))
                except socket.gaierror:
                    pass
            if ip is not None and (ip.is_private or ip.is_loopback):
                self.post("text", "box_whois",
                          f"[i] {ip} és una adreça privada/local.\n"
                          "    No existeix informació WHOIS pública sobre aquest dispositiu.\n",
                          "warn")
                return

            server = "whois.iana.org"
            for _ in range(3):  # segueix les referències (refer:)
                resp = self._whois_query(server, target)
                m = re.search(r"^(?:refer|whois):\s*(\S+)", resp, re.I | re.M)
                if m and m.group(1).lower() != server:
                    self.post("text", "box_whois", f"--- {server} ---\n{resp}\n", "muted")
                    server = m.group(1)
                else:
                    self.post("text", "box_whois", f"--- {server} ---\n{resp}\n", None)
                    break
        except Exception as e:
            self.post("text", "box_whois", f"Error WHOIS: {e}\n", "bad")
        finally:
            self.post("cmd_done", "WHOIS finalitzat.")

    @staticmethod
    def _whois_query(server, query):
        with socket.create_connection((server, 43), timeout=8) as s:
            s.sendall((query + "\r\n").encode())
            chunks = []
            while True:
                data = s.recv(4096)
                if not data:
                    break
                chunks.append(data)
        return b"".join(chunks).decode("utf-8", errors="ignore")

    # ------------------------- STOP -------------------------
    def stop_all(self):
        if not self.busy:
            return
        self.stop_event.set()
        if self.proc is not None:
            try:
                self.proc.terminate()
            except OSError:
                pass
        self.log("STOP sol·licitat...", "warn")


def main():
    root = tk.Tk()
    NexusApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()